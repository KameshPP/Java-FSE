# Student Course Portal - Angular Hands-On (Digital Nurture 5.0)

Kamesh's submission for the Angular (v20.0) Hands-On Exercise Book. Builds a single Student
Course Portal app across all 10 hands-ons rather than a separate project per exercise.

## Stack
- Angular 20 (standalone components, no NgModules)
- NgRx (store, effects, store-devtools) for hands-on 9
- RxJS for HTTP + async flows
- json-server as the mock REST API for hands-on 8
- Jasmine + Karma for unit tests (hands-on 10)

## Running it

```bash
npm install
npm run mock-api   # starts json-server on :3000, serves db.json
npm start          # ng serve, app on :4200
```

## Tests

```bash
npm test
```

## What's where
- `src/app/pages/` - route-level pages (home, course-list, course-detail, student-profile,
  the two enrollment forms, not-found)
- `src/app/components/` - reusable pieces (header, course-card)
- `src/app/services/` - CourseService, EnrollmentService, AuthService, LoadingService,
  NotificationService
- `src/app/store/` - NgRx course + enrollment slices (actions/reducer/selectors/effects)
- `src/app/guards/` - authGuard, unsavedChangesGuard
- `src/app/interceptors/` - auth token, global error handling, loading spinner
- `src/app/directives/` - appHighlight
- `src/app/pipes/` - creditLabel

## Notes
- Course data comes from json-server (`db.json`) once hands-on 8 is wired up - make sure it's
  running on port 3000 or the course list/home stats will show the error state.
- `/profile` and `/enroll*` routes are behind `authGuard` (currently hardcoded to logged-in,
  see `AuthService`).
- Redux DevTools extension recommended for watching the NgRx actions/state tree.
