import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container">
      <h2>404 - Page Not Found</h2>
      <p>That page doesn't exist. <a routerLink="/">Go home</a></p>
    </div>
  `
})
export class NotFoundComponent {}
