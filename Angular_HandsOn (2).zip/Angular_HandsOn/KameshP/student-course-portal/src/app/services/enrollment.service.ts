import { Injectable } from '@angular/core';
import { CourseService } from './course.service';
import { Course } from '../models/course.model';

@Injectable({ providedIn: 'root' })
export class EnrollmentService {
  private enrolledCourseIds: number[] = [];

  constructor(private courseService: CourseService) {}

  enroll(courseId: number): void {
    if (!this.enrolledCourseIds.includes(courseId)) {
      this.enrolledCourseIds.push(courseId);
    }
  }

  unenroll(courseId: number): void {
    this.enrolledCourseIds = this.enrolledCourseIds.filter((id) => id !== courseId);
  }

  isEnrolled(courseId: number): boolean {
    return this.enrolledCourseIds.includes(courseId);
  }

  // resolves the stored ids into full course objects via CourseService
  getEnrolledCourses(): Course[] {
    // NOTE: once CourseService moved to http, this needs the live list passed in
    // rather than pulled synchronously - kept simple for hands-on 6, revisited in 8/9
    return [];
  }

  getEnrolledIds(): number[] {
    return this.enrolledCourseIds;
  }
}
