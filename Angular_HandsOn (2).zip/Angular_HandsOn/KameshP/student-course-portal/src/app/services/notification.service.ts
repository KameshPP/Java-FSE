import { Injectable } from '@angular/core';

// this one gets provided at component level on purpose (see NotificationComponent)
// so every component that provides it gets its own isolated instance
@Injectable()
export class NotificationService {
  private messages: string[] = [];

  push(msg: string): void {
    this.messages.push(msg);
  }

  getAll(): string[] {
    return this.messages;
  }
}
