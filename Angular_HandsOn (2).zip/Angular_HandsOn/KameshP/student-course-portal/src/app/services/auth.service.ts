import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // hardcoded for now - swap for a real login flow later
  isLoggedIn = true;
}
