import 'zone.js';
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

// bootstrap the standalone root component - no AppModule in Angular 20
bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
