package com.cognizant.springlearn.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cognizant.springlearn.exception.EmployeeNotFoundException;
import com.cognizant.springlearn.model.Employee;

@Repository
public class EmployeeDao {

	// keeping this in-memory for now, no db hooked up yet
	private List<Employee> employees = new ArrayList<>();

	public List<Employee> getAllEmployees() {
		return employees;
	}

	public Employee getEmployee(Long id) throws EmployeeNotFoundException {
		for (Employee employee : employees) {
			if (employee.getId().equals(id)) {
				return employee;
			}
		}
		throw new EmployeeNotFoundException("Employee with id " + id + " not found");
	}

	public void addEmployee(Employee employee) {
		employees.add(employee);
	}

	public void updateEmployee(Employee employee) throws EmployeeNotFoundException {
		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i).getId().equals(employee.getId())) {
				employees.set(i, employee);
				return;
			}
		}
		throw new EmployeeNotFoundException("Employee with id " + employee.getId() + " not found");
	}

	public void deleteEmployee(Long id) throws EmployeeNotFoundException {
		for (Employee employee : employees) {
			if (employee.getId().equals(id)) {
				employees.remove(employee);
				return;
			}
		}
		throw new EmployeeNotFoundException("Employee with id " + id + " not found");
	}
}
