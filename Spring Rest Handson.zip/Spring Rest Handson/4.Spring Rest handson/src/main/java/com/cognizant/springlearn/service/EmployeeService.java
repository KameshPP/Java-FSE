package com.cognizant.springlearn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.springlearn.dao.EmployeeDao;
import com.cognizant.springlearn.exception.EmployeeNotFoundException;
import com.cognizant.springlearn.model.Employee;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	public List<Employee> getAllEmployees() {
		return employeeDao.getAllEmployees();
	}

	public Employee getEmployee(Long id) throws EmployeeNotFoundException {
		return employeeDao.getEmployee(id);
	}

	public void addEmployee(Employee employee) {
		employeeDao.addEmployee(employee);
	}

	public void updateEmployee(Employee employee) throws EmployeeNotFoundException {
		employeeDao.updateEmployee(employee);
	}

	public void deleteEmployee(Long id) throws EmployeeNotFoundException {
		employeeDao.deleteEmployee(id);
	}
}
