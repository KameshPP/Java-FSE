package com.cognizant.springlearn.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.cognizant.springlearn.model.Country;

@RestController
@RequestMapping("/countries")
public class CountryController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CountryController.class);

	// no db for this hands on, just keeping the list in memory
	private List<Country> countries = new ArrayList<>();

	@GetMapping
	public List<Country> getAllCountries() {
		return countries;
	}

	@GetMapping("/{code}")
	public Country getCountry(@PathVariable String code) {
		for (Country country : countries) {
			if (country.getCode().equalsIgnoreCase(code)) {
				return country;
			}
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Country not found for code " + code);
	}

	@PostMapping
	public Country addCountry(@RequestBody @Valid Country country) {
		LOGGER.info("Start");
		LOGGER.info("Adding country: {}", country);
		countries.add(country);
		return country;
	}

	@PutMapping
	public Country updateCountry(@RequestBody @Valid Country country) {
		for (int i = 0; i < countries.size(); i++) {
			if (countries.get(i).getCode().equalsIgnoreCase(country.getCode())) {
				countries.set(i, country);
				return country;
			}
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Country not found for code " + country.getCode());
	}

	@DeleteMapping("/{code}")
	public void deleteCountry(@PathVariable String code) {
		for (Country country : countries) {
			if (country.getCode().equalsIgnoreCase(code)) {
				countries.remove(country);
				return;
			}
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Country not found for code " + code);
	}
}
