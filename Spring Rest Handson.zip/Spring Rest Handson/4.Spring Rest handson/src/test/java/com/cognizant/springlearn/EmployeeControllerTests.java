package com.cognizant.springlearn;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
public class EmployeeControllerTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void updateEmployee_whenEmployeeNotFound_returns404() throws Exception {
		String payload = "{\"id\":9999,\"name\":\"Ghost\",\"salary\":1000,\"permanent\":true}";

		mockMvc.perform(put("/employees")
				.contentType(MediaType.APPLICATION_JSON)
				.content(payload))
				.andExpect(status().isNotFound());
	}
}
