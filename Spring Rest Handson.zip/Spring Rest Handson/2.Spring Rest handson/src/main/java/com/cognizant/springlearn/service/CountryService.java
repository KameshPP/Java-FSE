package com.cognizant.springlearn.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

@Service
public class CountryService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CountryService.class);

	public CountryService() {
		LOGGER.debug("Inside CountryService Constructor.");
	}

	public Country getCountry(String code) throws CountryNotFoundException {
		LOGGER.info("START");

		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");

		@SuppressWarnings("unchecked")
		List<Country> countryList = context.getBean("countryList", List.class);

		// case insensitive match, using a lambda instead of a plain for loop like
		// the doc suggests
		Country country = countryList.stream()
				.filter(c -> c.getCode().equalsIgnoreCase(code))
				.findFirst()
				.orElseThrow(() -> new CountryNotFoundException(code));

		LOGGER.info("END");
		return country;
	}

}
