package com.cognizant.employee.dao;

import java.util.ArrayList;

import com.cognizant.employee.model.Employee;

public class EmployeeDao {

	// this gets set once, when spring builds the bean from employee-config.xml
	private static ArrayList<Employee> EMPLOYEE_LIST;

	public EmployeeDao(ArrayList<Employee> employeeList) {
		EMPLOYEE_LIST = employeeList;
	}

	public ArrayList<Employee> getAllEmployees() {
		return EMPLOYEE_LIST;
	}
}
