package com.cognizant.employee.dao;

import java.util.ArrayList;

import com.cognizant.employee.model.Department;

public class DepartmentDao {

	// populated once via the constructor when spring reads employee-config.xml
	private static ArrayList<Department> DEPARTMENT_LIST;

	public DepartmentDao(ArrayList<Department> departmentList) {
		DEPARTMENT_LIST = departmentList;
	}

	public ArrayList<Department> getAllDepartments() {
		return DEPARTMENT_LIST;
	}
}
