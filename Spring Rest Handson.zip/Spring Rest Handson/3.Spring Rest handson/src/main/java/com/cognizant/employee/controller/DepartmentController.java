package com.cognizant.employee.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.employee.model.Department;
import com.cognizant.employee.service.DepartmentService;

@RestController
@CrossOrigin(origins = "*")
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;

	@GetMapping("/departments")
	public ArrayList<Department> getAllDepartments() {
		System.out.println("fetching all departments...");
		return departmentService.getAllDepartments();
	}
}
