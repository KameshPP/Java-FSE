package com.cognizant.springlearn.controller;

import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
public class AuthenticationController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

	// token is valid for 20 minutes
	private static final long EXPIRATION_TIME = 1200000;
	private static final String SECRET_KEY = "secretkey";

	@GetMapping("/authenticate")
	public Map<String, String> authenticate(@RequestHeader("Authorization") String authHeader) {
		LOGGER.info("Start");
		LOGGER.debug("authHeader: {}", authHeader);

		String user = getUser(authHeader);
		String token = generateJwt(user);

		Map<String, String> map = new HashMap<>();
		map.put("token", token);

		LOGGER.info("End");
		return map;
	}

	private String getUser(String authHeader) {
		LOGGER.info("Start");

		String encodedCredentials = authHeader.replace("Basic ", "");
		byte[] decodedBytes = Base64.getDecoder().decode(encodedCredentials);
		String decodedCredentials = new String(decodedBytes);

		String user = decodedCredentials.split(":")[0];
		LOGGER.debug("user: {}", user);

		LOGGER.info("End");
		return user;
	}

	private String generateJwt(String user) {
		LOGGER.info("Start");

		JwtBuilder builder = Jwts.builder();
		builder.setSubject(user);

		// set the token issue time as current time
		builder.setIssuedAt(new Date());

		// set the token expiry as 20 minutes from now
		builder.setExpiration(new Date((new Date()).getTime() + EXPIRATION_TIME));

		builder.signWith(SignatureAlgorithm.HS256, SECRET_KEY);

		String token = builder.compact();
		LOGGER.debug("token: {}", token);

		LOGGER.info("End");
		return token;
	}
}
