# spring-learn

REST service (`/countries`) secured with Spring Security, using JWT for authorization.

## Run

```
mvn clean package
mvn spring-boot:run
```

App starts on port 8090.

## Test flow

1. Get a token (basic auth with in-memory user `user` / `pwd`):

```
curl -s -u user:pwd http://localhost:8090/authenticate
```

Response:
```
{"token":"eyJhbGciOiJIUzI1NiJ9....."}
```

2. Call `/countries` using the token from step 1:

```
curl -s -H "Authorization: Bearer REPLACE_TOKEN_HERE" http://localhost:8090/countries
```

3. Try it with a tampered/invalid token to confirm it gets rejected.

## Notes

- Users (`admin`/`pwd`, `user`/`pwd`) are hardcoded in `SecurityConfig` for this exercise. In the JPA module these move to the DB.
- Token expiry is 20 minutes (`AuthenticationController.EXPIRATION_TIME`).
- Signing key is `secretkey` — same constant used in both `AuthenticationController` (sign) and `JwtAuthorizationFilter` (verify).
