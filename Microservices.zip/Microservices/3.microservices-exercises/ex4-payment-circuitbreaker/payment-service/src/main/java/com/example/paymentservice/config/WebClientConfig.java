package com.example.paymentservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient thirdPartyWebClient() {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(Duration.ofSeconds(2)); // network-level timeout

        return WebClient.builder()
                .baseUrl("http://localhost:8085") // this same service, see application.yml port
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }
}
