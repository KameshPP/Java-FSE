package com.example;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;


@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("Exercise 3: Ordered Test Execution")
class OrderedTests {

    
    private static final java.util.List<String> executionLog = new java.util.ArrayList<>();


    @BeforeEach
    void logStart(TestInfo info) {
        System.out.println("▶ Starting: " + info.getDisplayName());
    }

    @AfterEach
    void logEnd(TestInfo info) {
        System.out.println("✔ Finished: " + info.getDisplayName());
    }

    @AfterAll
    static void printLog() {
        System.out.println("\nExecution order recorded: " + executionLog);
    }

   

    @Test
    @Order(1)
    @DisplayName("Step 1 – Initialize the system")
    void initializeSystem() {
        executionLog.add("init");
        System.out.println("  [1] Initializing system…");
        assertTrue(executionLog.contains("init"), "init should be logged first");
    }

    @Test
    @Order(2)
    @DisplayName("Step 2 – Load configuration")
    void loadConfiguration() {
        executionLog.add("config");
        System.out.println("  [2] Loading configuration…");
     
        assertEquals("init", executionLog.get(0), "init must precede config");
        assertTrue(executionLog.contains("config"));
    }

    @Test
    @Order(3)
    @DisplayName("Step 3 – Connect to database")
    void connectToDatabase() {
        executionLog.add("db-connect");
        System.out.println("  [3] Connecting to database…");
        assertEquals(2, executionLog.size() - 1,
            "db-connect should be the third entry");
    }

    @Test
    @Order(4)
    @DisplayName("Step 4 – Execute business logic")
    void executeBusinessLogic() {
        executionLog.add("business-logic");
        System.out.println("  [4] Executing business logic…");
        assertTrue(executionLog.contains("db-connect"),
            "Database must be connected before business logic runs");
    }

    @Test
    @Order(5)
    @DisplayName("Step 5 – Verify and shut down")
    void verifyAndShutdown() {
        executionLog.add("shutdown");
        System.out.println("  [5] Shutting down…");

        assertEquals(java.util.List.of("init", "config", "db-connect", "business-logic", "shutdown"),
            executionLog,
            "Full execution sequence must match expected order");
    }


    @Test
    @Order(10)
    @DisplayName("Bonus – Arithmetic sanity check")
    void arithmeticSanityCheck() {
        assertEquals(42, 6 * 7, "6 × 7 should equal 42");
    }
}
