package com.example;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import static org.junit.jupiter.api.Assertions.*;


@DisplayName("Exercise 5: Timeout and Performance Testing")
class PerformanceTesterTest {

    private final PerformanceTester tester = new PerformanceTester();


    @Test
    @DisplayName("Fast task completes within 500 ms (assertTimeout)")
    void fastTaskCompletesWithinLimit() {
       
        Duration limit = Duration.ofMillis(500);

      
        String result = assertTimeout(limit,
            () -> tester.performFastTask(),
            "performFastTask() should finish well within 500 ms"
        );

        assertEquals("fast-result", result, "Return value should be 'fast-result'");
    }

    @Test
    @DisplayName("Configurable task (100 ms) passes a 500 ms limit (assertTimeout)")
    void configurableTaskPassesLimit() {
        assertTimeout(Duration.ofMillis(500),
            () -> tester.performTask(100));
    }


    @Test
    @DisplayName("Fast task completes within 500 ms (assertTimeoutPreemptively)")
    void fastTaskPreemptiveTimeout() {
        assertTimeoutPreemptively(
            Duration.ofMillis(500),
            () -> tester.performFastTask(),
            "performFastTask() must not exceed 500 ms"
        );
    }

    @Test
    @DisplayName("Slow task (2 s) is expected to exceed a 500 ms preemptive limit")
    void slowTaskExceedsPreemptiveLimit() {
       
        assertThrows(
            AssertionError.class,
            () -> assertTimeoutPreemptively(
                    Duration.ofMillis(500),
                    () -> tester.performSlowTask()
            ),
            "assertTimeoutPreemptively should throw AssertionError for a 2 s task within 500 ms"
        );
    }

    @Test
    @Timeout(value = 500, unit = TimeUnit.MILLISECONDS)
    @DisplayName("Fast task passes @Timeout(500 ms)")
    void fastTaskAnnotationTimeout() throws InterruptedException {
      
        tester.performFastTask();
    }

    @Test
    @Timeout(value = 1, unit = TimeUnit.SECONDS)
    @DisplayName("Configurable task (200 ms) passes @Timeout(1 s)")
    void configurableTaskAnnotationTimeout() {
        String result = tester.performTask(200);
        assertNotNull(result, "Result must not be null");
    }

  

    @Test
    @DisplayName("Task finishing at exactly ~50 ms comfortably passes a 300 ms limit")
    void boundaryTaskPassesComfortably() {
        long taskDurationMs  = 50;
        Duration limit       = Duration.ofMillis(300);

        assertTimeout(limit, () -> tester.performTask(taskDurationMs),
            "A " + taskDurationMs + " ms task should pass a " + limit.toMillis() + " ms limit");
    }
}
