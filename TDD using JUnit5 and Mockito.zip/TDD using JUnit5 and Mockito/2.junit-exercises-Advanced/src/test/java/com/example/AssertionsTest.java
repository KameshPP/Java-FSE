package com.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class AssertionsTest {

    @Test
    public void testAssertEquals() {
        assertEquals("2 + 3 should equal 5", 5, 2 + 3);
        assertEquals("String comparison", "hello", "hel" + "lo");
        assertEquals("Double comparison with delta", 3.14, Math.PI, 0.01);
    }

    @Test
    public void testAssertTrue() {
        assertTrue("5 should be greater than 3", 5 > 3);
        assertTrue("List should be empty",  new java.util.ArrayList<>().isEmpty());
    }

    @Test
    public void testAssertFalse() {
       
        assertFalse("5 should not be less than 3", 5 < 3);
        assertFalse("Non-empty string is not blank", "hello".isEmpty());
    }

    @Test
    public void testAssertNull() {
       
        String s = null;
        assertNull("Variable should be null", s);
    }

    @Test
    public void testAssertNotNull() {
      
        Object obj = new Object();
        assertNotNull("Object should not be null", obj);
        assertNotNull("New string should not be null", new String("test"));
    }

    @Test
    public void testAssertSame() {
       
        String a = "shared";
        String b = a;
        assertSame("Both variables should reference the same object", a, b);
    }

    @Test
    public void testAssertNotSame() {
       
        String a = new String("hello");
        String b = new String("hello");
        assertNotSame("Different instances should not be the same reference", a, b);
    }

    @Test
    public void testAssertArrayEquals() {
        
        int[] expected = {1, 2, 3};
        int[] actual   = {1, 2, 3};
        assertArrayEquals("Arrays should be equal", expected, actual);
    }

    @Test
    public void testAllAssertionsTogether() {
        assertEquals(5, 2 + 3);
        assertTrue(5 > 3);
        assertFalse(5 < 3);
        assertNull(null);
        assertNotNull(new Object());
    }
}
