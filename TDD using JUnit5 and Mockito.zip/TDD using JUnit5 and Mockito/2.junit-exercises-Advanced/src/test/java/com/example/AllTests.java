package com.example;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;


@Suite
@SuiteDisplayName("All JUnit Advanced Exercises – Full Suite")
@SelectClasses({
   
    CalculatorTest.class,
    AssertionsTest.class,
    BankAccountTest.class,

   
    EvenCheckerTest.class,
    OrderedTests.class,
    ExceptionThrowerTest.class,
    PerformanceTesterTest.class
})
public class AllTests {
   
}
