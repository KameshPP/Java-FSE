package com.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;


public class BankAccountTest {

    private BankAccount account;


    @Before
    public void setUp() {
        
        account = new BankAccount("Alice", 1000.0);
        System.out.println("setUp() – fresh BankAccount created with balance 1000.0");
    }

    @After
    public void tearDown() {
        account = null;
        System.out.println("tearDown() – BankAccount reference cleared");
    }

    @Test
    public void testDeposit() {
        
        double depositAmount = 500.0;

      
        account.deposit(depositAmount);

        assertEquals("Balance after deposit should be 1500.0",
                1500.0, account.getBalance(), 0.001);
    }

    @Test
    public void testWithdraw() {
       
        double withdrawAmount = 200.0;

        
        account.withdraw(withdrawAmount);

        assertEquals("Balance after withdrawal should be 800.0",
                800.0, account.getBalance(), 0.001);
    }

    @Test
    public void testMultipleTransactions() {
        
        double deposit    = 300.0;
        double withdrawal = 150.0;

       
        account.deposit(deposit);
        account.withdraw(withdrawal);

        
        assertEquals("Balance after deposit then withdrawal should be 1150.0",
                1150.0, account.getBalance(), 0.001);
    }

    @Test(expected = IllegalStateException.class)
    public void testOverdraftThrowsException() {
        
        double overdraftAmount = 9999.0;

        account.withdraw(overdraftAmount);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativeDepositThrowsException() {
    
        double negativeAmount = -50.0;

        account.deposit(negativeAmount);
    }

    @Test
    public void testInitialOwner() {


       
        String owner = account.getOwner();

        
        assertEquals("Owner should be Alice", "Alice", owner);
    }

    @Test
    public void testInitialBalance() {
       
        double balance = account.getBalance();

        assertEquals("The Initial balance should be 1000.0", 1000.0, balance, 0.001);
    }
}
