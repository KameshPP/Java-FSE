package com.example;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


@DisplayName("Exercise 4: Exception Testing")
class ExceptionThrowerTest {

    private final ExceptionThrower thrower = new ExceptionThrower();

  
    @Test
    @DisplayName("throwException() must throw IllegalArgumentException")
    void throwExceptionThrowsIllegalArgumentException() {
        
        assertThrows(
            IllegalArgumentException.class,
            () -> thrower.throwException("bad-value"),
            "throwException() should throw IllegalArgumentException"
        );
    }

   

    @Test
    @DisplayName("Exception message should contain the bad input value")
    void exceptionMessageContainsInputValue() {
       
        String badInput = "bad-value";

      
        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> thrower.throwException(badInput)
        );

        
        assertTrue(
            ex.getMessage().contains(badInput),
            "Message should contain the rejected input: " + ex.getMessage()
        );
    }

    @Test
    @DisplayName("throwException(null) must throw IllegalArgumentException")
    void throwExceptionWithNullInput() {
        assertThrows(
            IllegalArgumentException.class,
            () -> thrower.throwException(null)
        );
    }

    @Test
    @DisplayName("throwException(blank) must throw IllegalArgumentException")
    void throwExceptionWithBlankInput() {
        assertThrows(
            IllegalArgumentException.class,
            () -> thrower.throwException("   ")
        );
    }

 
    @Test
    @DisplayName("divide() throws ArithmeticException when denominator is 0")
    void divideByZeroThrowsArithmeticException() {
        ArithmeticException ex = assertThrows(
            ArithmeticException.class,
            () -> thrower.divide(10, 0)
        );
        assertTrue(ex.getMessage().toLowerCase().contains("zero"),
            "Message should mention 'zero'");
    }

    @Test
    @DisplayName("divide() succeeds for normal inputs (no exception)")
    void divideNormalInputsDoesNotThrow() {
        
        int result = assertDoesNotThrow(
            () -> thrower.divide(10, 2),
            "divide(10, 2) should NOT throw any exception"
        );
        assertEquals(5, result);
    }

   
    @Test
    @DisplayName("notImplemented() throws UnsupportedOperationException")
    void notImplementedThrowsUnsupportedOperationException() {
        assertThrows(
            UnsupportedOperationException.class,
            () -> thrower.notImplemented()
        );
    }
}
