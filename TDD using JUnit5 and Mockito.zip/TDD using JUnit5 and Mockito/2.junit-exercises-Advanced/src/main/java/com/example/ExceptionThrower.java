package com.example;


public class ExceptionThrower {


    public void throwException(String input) {
        if (input == null || input.isBlank()) {
            throw new IllegalArgumentException("Input must not be null or blank, but got: '" + input + "'");
        }
        throw new IllegalArgumentException("Invalid input value: " + input);
    }


    public int divide(int numerator, int denominator) {
        if (denominator == 0) {
            throw new ArithmeticException("Division by zero is undefined");
        }
        return numerator / denominator;
    }


    public void notImplemented() {
        throw new UnsupportedOperationException("This feature is not yet implemented");
    }
}
