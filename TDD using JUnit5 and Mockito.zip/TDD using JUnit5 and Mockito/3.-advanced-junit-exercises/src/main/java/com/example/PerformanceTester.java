package com.example;


public class PerformanceTester {

    public String performFastTask() {
        sleep(50);
        return "fast-result";
    }

    public String performSlowTask() {
        sleep(2_000);
        return "slow-result";
    }


    public String performTask(long durationMs) {
        sleep(durationMs);
        return "result-after-" + durationMs + "ms";
    }


    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
