package com.example;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;


@Suite
@SuiteDisplayName("All JUnit Advanced Exercises – Full Suite")
@SelectClasses({
    // Basic exercises (JUnit 4, run via Vintage engine)
    CalculatorTest.class,
    AssertionsTest.class,
    BankAccountTest.class,

    // Advanced exercises (JUnit 5)
    EvenCheckerTest.class,
    OrderedTests.class,
    ExceptionThrowerTest.class,
    PerformanceTesterTest.class
})
public class AllTests {

}
