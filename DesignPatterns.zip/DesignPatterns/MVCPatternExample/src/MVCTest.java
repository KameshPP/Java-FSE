public class MVCTest {

    public static void main(
            String[] args
    ) {

        Student s =
                new Student(
                        "Kamesh",
                        101,
                        "A"
                );

        StudentView view =
                new StudentView();

        StudentController c =
                new StudentController(
                        s,
                        view
                );

        c.show();

        c.updateName(
                "Kumar"
        );

        c.show();
    }
}