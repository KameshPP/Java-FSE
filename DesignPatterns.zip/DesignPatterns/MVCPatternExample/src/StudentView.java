class StudentView {

    public void display(
            Student s
    ) {
        System.out.println(
                s.getName()
        );

        System.out.println(
                s.getId()
        );

        System.out.println(
                s.getGrade()
        );
    }
}