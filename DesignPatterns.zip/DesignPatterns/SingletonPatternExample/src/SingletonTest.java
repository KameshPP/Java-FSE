public class SingletonTest {

    public static void main(String[] args) {

        // Get logger instances
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        // Use logger
        logger1.log("Application started");
        logger2.log("User logged in");

        // Check if both references point to same object
        if (logger1 == logger2) {
            System.out.println("Only one Logger instance exists");
        } else {
            System.out.println("Multiple instances created");
        }
    }
}