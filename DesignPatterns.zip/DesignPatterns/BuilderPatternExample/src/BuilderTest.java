public class BuilderTest {

    public static void main(String[] args) {

        Computer gamingPC =
                new Computer.Builder()
                        .setCPU("Intel i9")
                        .setRAM(32)
                        .setStorage(1000)
                        .setGPU("RTX 4070")
                        .build();

        Computer officePC =
                new Computer.Builder()
                        .setCPU("Intel i5")
                        .setRAM(16)
                        .setStorage(512)
                        .build();

        gamingPC.display();
        officePC.display();
    }
}