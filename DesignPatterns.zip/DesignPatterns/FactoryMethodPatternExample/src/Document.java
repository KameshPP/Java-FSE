interface Document {
    void open();
}