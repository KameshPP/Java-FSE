interface Image {

    void display();

}