class WebApp implements Observer {

    public void update(double price) {
        System.out.println(
                "Web: Stock price = ₹" + price
        );
    }
}