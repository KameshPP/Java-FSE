public class ObserverTest {

    public static void main(String[] args) {

        StockMarket market =
                new StockMarket();

        market.register(new MobileApp());
        market.register(new WebApp());

        market.setStockPrice(2500);
    }
}