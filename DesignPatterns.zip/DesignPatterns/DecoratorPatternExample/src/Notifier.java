interface Notifier {

    void send();

}