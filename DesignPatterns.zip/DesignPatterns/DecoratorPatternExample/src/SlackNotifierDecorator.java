class SlackNotifierDecorator extends NotifierDecorator {

    public SlackNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send() {
        super.send();
        sendSlack();
    }

    private void sendSlack() {
        System.out.println("Sending notification via Slack");
    }
}