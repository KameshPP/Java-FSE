public class StrategyTest {

    public static void main(String[] args) {

        PaymentContext context =
                new PaymentContext();

        context.setStrategy(
                new CreditCardPayment()
        );

        context.execute(5000);

        context.setStrategy(
                new PayPalPayment()
        );

        context.execute(3000);
    }
}