class PaymentContext {

    private PaymentStrategy strategy;

    public void setStrategy(
            PaymentStrategy strategy
    ) {
        this.strategy = strategy;
    }

    public void execute(
            double amount
    ) {
        strategy.pay(amount);
    }
}