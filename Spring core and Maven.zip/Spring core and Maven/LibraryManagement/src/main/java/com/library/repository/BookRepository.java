package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    public String findBookById(int id) {
        return "Book " + id + ": The Great Gatsby by F. Scott Fitzgerald";
    }

    public void save(String title) {
        System.out.println("Saved book to repository: " + title);
    }
}
