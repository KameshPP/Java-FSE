package com.library;

import com.library.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LibraryManagementApplication {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        System.out.println("\n--- Annotation scanned bean (setter injection via @Autowired) ---");
        BookService bookService = context.getBean("bookService", BookService.class);
        System.out.println(bookService.getBookDetails(101));
        bookService.addBook("Spring in Action");

        System.out.println("\n--- XML bean, constructor injection ---");
        BookService constructorWired = context.getBean("bookServiceXml", BookService.class);
        System.out.println(constructorWired.getBookDetails(202));

        System.out.println("\n--- XML bean, setter injection ---");
        BookService setterWired = context.getBean("bookServiceSetter", BookService.class);
        System.out.println(setterWired.getBookDetails(303));
    }
}
