public class EmployeeArrayStore {
    private Employee[] employees;
    private int size; // number of employees currently stored

    public EmployeeArrayStore(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add an employee at the next free slot. Returns false if the array is full.
    public boolean add(Employee emp) {
        if (size == employees.length) {
            return false; // array is full (would need resizing in a dynamic array)
        }
        employees[size] = emp;
        size++;
        return true;
    }

    // Linear search by employeeId. Returns the index, or -1 if not found.
    public int search(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return i;
            }
        }
        return -1;
    }

    // Visit every employee in order.
    public void traverse() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete by employeeId. Shifts subsequent elements left to close the gap.
    public boolean delete(String employeeId) {
        int idx = search(employeeId);
        if (idx == -1) return false;

        for (int i = idx; i < size - 1; i++) {
            employees[i] = employees[i + 1];
        }
        employees[size - 1] = null; // clear the now-unused last slot
        size--;
        return true;
    }
}
