public class Main {
    public static void main(String[] args) {
        EmployeeArrayStore store = new EmployeeArrayStore(10);

        store.add(new Employee("E001", "Maria Lopez", "Engineer", 85000));
        store.add(new Employee("E002", "John Smith", "Manager", 95000));
        store.add(new Employee("E003", "Priya Patel", "Designer", 78000));

        System.out.println("All employees:");
        store.traverse();

        int idx = store.search("E002");
        System.out.println("Found E002 at index: " + idx);

        store.delete("E002");
        System.out.println("After deleting E002:");
        store.traverse();
    }
}
