public class Main {
    public static void main(String[] args) {
        Product[] products = {
                new Product("P003", "Yoga Mat", "Fitness"),
                new Product("P001", "Wireless Mouse", "Electronics"),
                new Product("P004", "Running Shoes", "Footwear"),
                new Product("P002", "Mechanical Keyboard", "Electronics"),
        };

        // Linear search works on the unsorted array directly.
        int idx1 = LinearSearch.search(products, "Running Shoes");
        System.out.println("Linear search found at index: " + idx1);

        // Binary search requires sorting first.
        BinarySearch.sortByName(products);
        int idx2 = BinarySearch.search(products, "Running Shoes");
        System.out.println("Binary search found at index: " + idx2);
    }
}
