public class LinearSearch {
    // Returns the index of the product with matching productName, or -1 if not found.
    public static int search(Product[] products, String targetName) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductName().equalsIgnoreCase(targetName)) {
                return i; // found
            }
        }
        return -1; // not found
    }
}
