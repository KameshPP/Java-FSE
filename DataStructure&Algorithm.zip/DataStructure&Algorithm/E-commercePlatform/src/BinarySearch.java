import java.util.Arrays;
import java.util.Comparator;

public class BinarySearch {
    // Array must already be sorted by productName before calling this.
    public static int search(Product[] sortedProducts, String targetName) {
        int low = 0;
        int high = sortedProducts.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            int cmp = sortedProducts[mid].getProductName().compareToIgnoreCase(targetName);

            if (cmp == 0) {
                return mid; // found
            } else if (cmp < 0) {
                low = mid + 1;  // target is in the right half
            } else {
                high = mid - 1; // target is in the left half
            }
        }
        return -1; // not found
    }

    // Helper to sort the array by productName before binary search.
    public static void sortByName(Product[] products) {
        Arrays.sort(products, Comparator.comparing(Product::getProductName));
    }
}
