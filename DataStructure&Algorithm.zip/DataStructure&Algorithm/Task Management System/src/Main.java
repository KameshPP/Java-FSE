public class Main {
    public static void main(String[] args) {
        TaskLinkedList tasks = new TaskLinkedList();

        tasks.add(new Task("T1", "Design database schema", "DONE"));
        tasks.add(new Task("T2", "Build REST API", "IN_PROGRESS"));
        tasks.add(new Task("T3", "Write unit tests", "PENDING"));

        System.out.println("All tasks:");
        tasks.traverse();

        Task found = tasks.search("T2");
        System.out.println("Found: " + found);

        tasks.delete("T2");
        System.out.println("After deleting T2:");
        tasks.traverse();
    }
}
