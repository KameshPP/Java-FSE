public class Task {
    private String taskId;
    private String taskName;
    private String status; // e.g., "PENDING", "IN_PROGRESS", "DONE"

    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    public String getTaskId()   { return taskId; }
    public String getTaskName() { return taskName; }
    public String getStatus()   { return status; }

    @Override
    public String toString() {
        return String.format("Task[id=%s, name=%s, status=%s]", taskId, taskName, status);
    }
}
