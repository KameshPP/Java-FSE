public class TaskLinkedList {

    // Internal node class
    private static class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    private Node head;
    private int size;

    public TaskLinkedList() {
        head = null;
        size = 0;
    }

    // Add a task to the end of the list.
    public void add(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    // Search by taskId. Returns the Task, or null if not found.
    public Task search(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Visit every task in order from head to tail.
    public void traverse() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete by taskId. Returns true if a task was removed.
    public boolean delete(String taskId) {
        if (head == null) return false;

        // Special case: deleting the head node.
        if (head.task.getTaskId().equals(taskId)) {
            head = head.next;
            size--;
            return true;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.task.getTaskId().equals(taskId)) {
                current.next = current.next.next; // unlink the matching node
                size--;
                return true;
            }
            current = current.next;
        }
        return false; // not found
    }

    public int size() {
        return size;
    }
}
