public class Main {
    public static void main(String[] args) {
        double currentRevenue = 100000.0; // e.g., $100,000 this year
        double annualGrowthRate = 0.08;   // 8% growth per year
        int yearsAhead = 5;

        double forecast = FinancialForecast.predictFutureValue(
                currentRevenue, annualGrowthRate, yearsAhead);

        System.out.printf("Forecasted revenue in %d years: %.2f%n", yearsAhead, forecast);
    }
}
