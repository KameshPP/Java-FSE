public class FinancialForecast {

    /**
     * Recursively predicts the future value after 'periods' periods of growth.
     *
     * @param presentValue the starting value (e.g., current revenue)
     * @param growthRate   the per-period growth rate as a decimal (e.g., 0.05 for 5%)
     * @param periods      how many periods into the future to forecast
     * @return the predicted future value
     */
    public static double predictFutureValue(double presentValue, double growthRate, int periods) {
        // Base case: zero periods means no growth has been applied yet.
        if (periods == 0) {
            return presentValue;
        }
        // Recursive case: grow the value for one more period, then recurse
        // on the remaining (periods - 1) periods.
        return predictFutureValue(presentValue * (1 + growthRate), growthRate, periods - 1);
    }
}
