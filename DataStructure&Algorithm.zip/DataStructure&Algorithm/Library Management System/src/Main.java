public class Main {
    public static void main(String[] args) {
        Book[] books = {
                new Book("B3", "The Hobbit", "J.R.R. Tolkien"),
                new Book("B1", "Dune", "Frank Herbert"),
                new Book("B4", "1984", "George Orwell"),
                new Book("B2", "Foundation", "Isaac Asimov"),
        };

        // Linear search works directly on the unsorted array.
        Book found1 = LinearBookSearch.findByTitle(books, "1984");
        System.out.println("Linear search result: " + found1);

        // Binary search requires sorting first.
        BinaryBookSearch.sortByTitle(books);
        Book found2 = BinaryBookSearch.findByTitle(books, "1984");
        System.out.println("Binary search result: " + found2);
    }
}
