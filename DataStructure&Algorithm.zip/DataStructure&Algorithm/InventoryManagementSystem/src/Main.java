public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        inventory.addProduct(new Product("P001", "Wireless Mouse", 150, 19.99));
        inventory.addProduct(new Product("P002", "Mechanical Keyboard", 80, 49.99));

        inventory.updateProduct("P001", 140, 17.99); // sold 10 units, price drop

        System.out.println(inventory.getProduct("P001"));

        inventory.deleteProduct("P002");

        for (Product p : inventory.getAllProducts()) {
            System.out.println(p);
        }
    }
}
