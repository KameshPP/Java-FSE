import java.util.HashMap;
import java.util.Collection;

public class Inventory {
    // productId -> Product
    private HashMap<String, Product> products = new HashMap<>();

    // Add a new product. Returns false if the ID already exists.
    public boolean addProduct(Product product) {
        if (products.containsKey(product.getProductId())) {
            return false; // avoid overwriting an existing product silently
        }
        products.put(product.getProductId(), product);
        return true;
    }

    // Update quantity and/or price for an existing product.
    public boolean updateProduct(String productId, int newQuantity, double newPrice) {
        Product p = products.get(productId);
        if (p == null) return false;
        p.setQuantity(newQuantity);
        p.setPrice(newPrice);
        return true;
    }

    // Delete a product by ID.
    public boolean deleteProduct(String productId) {
        return products.remove(productId) != null;
    }

    // Look up a single product.
    public Product getProduct(String productId) {
        return products.get(productId);
    }

    public Collection<Product> getAllProducts() {
        return products.values();
    }
}
