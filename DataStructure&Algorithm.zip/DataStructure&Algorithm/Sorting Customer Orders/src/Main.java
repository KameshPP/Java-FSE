public class Main {
    public static void main(String[] args) {
        Order[] bubbleOrders = {
                new Order("O1", "Alice", 250.00),
                new Order("O2", "Bob", 75.50),
                new Order("O3", "Carla", 420.00),
                new Order("O4", "Dan", 120.25),
        };
        BubbleSort.sort(bubbleOrders);
        System.out.println("Bubble sorted:");
        for (Order o : bubbleOrders) System.out.println(o);

        Order[] quickOrders = {
                new Order("O1", "Alice", 250.00),
                new Order("O2", "Bob", 75.50),
                new Order("O3", "Carla", 420.00),
                new Order("O4", "Dan", 120.25),
        };
        QuickSort.sort(quickOrders);
        System.out.println("Quick sorted:");
        for (Order o : quickOrders) System.out.println(o);
    }
}
