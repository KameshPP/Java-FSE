public class QuickSort {
    public static void sort(Order[] orders) {
        quickSort(orders, 0, orders.length - 1);
    }

    private static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(orders, low, high);
            quickSort(orders, low, pivotIndex - 1);
            quickSort(orders, pivotIndex + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivotValue = orders[high].getTotalPrice(); // pivot = last element
        int i = low - 1; // boundary of "smaller than pivot" region

        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() < pivotValue) {
                i++;
                swap(orders, i, j);
            }
        }
        swap(orders, i + 1, high); // move pivot into its correct position
        return i + 1;
    }

    private static void swap(Order[] orders, int a, int b) {
        Order temp = orders[a];
        orders[a] = orders[b];
        orders[b] = temp;
    }
}
